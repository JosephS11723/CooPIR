import tests

tests.runAllTests()